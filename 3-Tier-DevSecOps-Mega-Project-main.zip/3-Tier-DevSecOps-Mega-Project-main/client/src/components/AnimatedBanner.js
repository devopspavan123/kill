import React from 'react';

function AnimatedBanner({ message }) {
  return <div className="animated-banner">{message}</div>;
}

export default AnimatedBanner;
